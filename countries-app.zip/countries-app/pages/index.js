import React, { useEffect, useState } from 'react'
import Image from 'next/image'
import ReactPaginate from 'react-paginate'

export default function Index(props) {
  const { response } = props;
  const [countryDetails, setCountryDetails] = useState(null);
  const [currency, setCurrency] = useState(null);
  const [currentItems, setCurrentItems] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [itemOffset, setItemOffset] = useState(0);

  const getCountryDetails = async (name) => {
    const res = await fetch(`https://restcountries.com/v3.1/name/${name}`);
    const data = await res.json();
    const { currencies } = data[0];
    setCurrency(Object.values(currencies));
    setCountryDetails(data);
  };

  const handlePageClick = (event) => {
    const newOffset = event.selected * 20 % response.length;
    setItemOffset(newOffset);
  };

  useEffect(() => {
    const endOffset = itemOffset + 20;
    setCurrentItems(response.slice(itemOffset, endOffset));
    setPageCount(Math.ceil(response.length / 20));
  }, [itemOffset, response]);

  return (
    <div className='main-content'>
      {/** Country List */}
      <div className='country-list'>
        <h1 className='section-title'>Country List</h1>
        {currentItems.map((country, index) => (
          <button onClick={() => getCountryDetails(country.name.official)} className='country-btn' key={index+country.name.official}>
            {country.name.common}
          </button>
        ))}

        <ReactPaginate
          nextLabel="next >"
          onPageChange={handlePageClick}
          pageRangeDisplayed={3}
          marginPagesDisplayed={2}
          pageCount={pageCount}
          previousLabel="< previous"
          pageClassName="page-item"
          pageLinkClassName="page-link"
          previousClassName="page-item"
          previousLinkClassName="page-link"
          nextClassName="page-item"
          nextLinkClassName="page-link"
          breakLabel="..."
          breakClassName="page-item"
          breakLinkClassName="page-link"
          containerClassName="pagination"
          activeClassName="active"
          renderOnZeroPageCount={null}
        />
      </div>

      <div className='country-summary'>
        <div className='country-info'>
          <h1 className='section-title'>Country</h1>

          {countryDetails !== null && (
            <React.Fragment>
              <div className='image-container'>
                <Image src={countryDetails[0].flags.png} alt="Country Flag" layout="fill" />
              </div>

              <p className='country-name-desc'>
                <span>{countryDetails[0].name.official}</span>
                <a href={`https://en.wikipedia.org/wiki/${countryDetails[0].name.official}`} target="_black">Go to wikipedia</a>
              </p>
            </React.Fragment>
          )}
        </div>

        <div className='country-details'>
          <h1 className='section-title'>Country Details</h1>

          {countryDetails !== null && (
          <div className='country-details-content'>
            {countryDetails[0]?.coatOfArms?.png ? (
              <div className='image-container'>
                <Image src={countryDetails[0].coatOfArms.png} alt="Country Flag" layout="fill" />
              </div>
            ) : (
              <div className='image-container'></div>
            )}

            <div className="country-details-columns">
              <div>
                <label className='country-label'>Official Name</label>
                <p>{countryDetails[0].name.official}</p>
              </div>

              <div>
                <label className='country-label'>Population</label>
                <p>{countryDetails[0].population}</p>
              </div>
              
              <div>
                <label className='country-label'>Continent</label>
                <p>{countryDetails[0].continents[0]}</p>
              </div>

              <div>
                <label className='country-label'>Currency</label>
                <p>{currency[0].name}({currency[0].symbol})</p>
              </div>

              <div>
                <label className='country-label'>Capital</label>
                <p>{countryDetails[0].capital[0]}</p>
              </div>
            </div>
          </div>
          )}
        </div>
      </div>
    </div>
  )
}

export async function getServerSideProps() {
  const res = await fetch(`${process.env.BASE_URL}/api/countries`);
  const response = await res.json();

  return {
    props: { response },
  };
}