import axios from "axios";

export default function handler(req, res) {
  const options = {
    method: "GET",
    url: 'https://restcountries.com/v3.1/all',
  };

  axios
    .request(options)
    .then(function (response) {
      res.status(200).json(response.data);
    })
    .catch(function (error) {
      res.status(500).json(error);
    });
}
